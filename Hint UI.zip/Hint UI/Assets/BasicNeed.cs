﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicNeed : MonoBehaviour {

    public SimpleHealthBar foodBar, waterBar, peeBar;

    public float food = 10;
    public float water = 10;
    public float pee = 10;
    public float pCoef = 3;
    public float fCoef = 4;
    public float wCoef = 4;

	// Use this for initialization
	void Start () {
    }
	
	// Update is called once per frame
	void Update () {
        food -= Time.deltaTime * fCoef / 60;
        water -= Time.deltaTime * wCoef / 60;
        pee -= Time.deltaTime * pCoef / 100;
        foodBar.UpdateBar(food, 10);
        waterBar.UpdateBar(water, 10);
        peeBar.UpdateBar(pee, 10);
    }
}
