﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plate : MonoBehaviour {

    Transform food;
    float eatingTime = 0;
    public SimpleHealthBar eatBar;
    float eat = 10;
    float foodTime = 10;
    public BasicNeed bn;

    // Use this for initialization
    void Start () {
        food = transform.Find("Food");
    }
	
	// Update is called once per frame
	void Update () {
        if (eatingTime > 0)
        {
            eat = foodTime-eatingTime;
            eatBar.UpdateBar(eat, foodTime);
            if (eatingTime > foodTime)
            {
                food.gameObject.SetActive(false);
                eatBar.transform.parent.gameObject.SetActive(false);
                eatingTime = 0;
                bn.food = 10;
                this.transform.parent = null;
            }
        }
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.name == "Kitchen")
        {
            Debug.Log("Collide with kitchen");
            food.gameObject.SetActive(true);
        }
        if (other.name == "Dinning Table")
        {
            eatBar.transform.parent.gameObject.SetActive(true);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.name == "Dinning Table" && food.gameObject.activeSelf)
        {
            eatingTime += Time.deltaTime;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.name == "Dinning Table")
        {
            eatBar.transform.parent.gameObject.SetActive(false);
        }
    }
}
