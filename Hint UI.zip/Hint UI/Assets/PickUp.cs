﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUp : MonoBehaviour {

    public float distance = 2;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Vector3 delta = new Vector3(2, 0, 2);
            this.transform.parent = other.transform;
            this.transform.position = Camera.main.transform.position + Camera.main.transform.forward * distance;
        }
    }
}
